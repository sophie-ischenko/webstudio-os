import { useEffect, useState, useCallback } from 'react';
import {
  Plus,
  Trash2,
  Building2,
  ExternalLink,
  AlertCircle,
  Calendar,
  RefreshCw,
  Pencil,
} from 'lucide-react';

import { suppliers, uuid } from '../lib/db';
import type { Supplier } from '../types';
import { formatMoney, formatDate, daysUntil } from '../lib/format';
import { Badge, EmptyState, Field, Modal, SectionHeader } from '../components/ui';

const CATEGORY_LABELS: Record<string, string> = {
  hosting: 'Hosting',
  software: 'Software',
  hardware: 'Hardware',
  service: 'Service',
};

export function SuppliersView() {
  const [list, setList] = useState<Supplier[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);

  const load = useCallback(async () => {
    setList(await suppliers.list());
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function remove(id: string) {
    await suppliers.remove(id);
    load();
  }

  async function toggleActive(s: Supplier) {
    await suppliers.update(s.id, { active: s.active ? 0 : 1 });
    load();
  }

  const active = list.filter(s => s.active);

  const monthlyTotal = active.reduce((s, sup) => {
    if (sup.billing_cycle === 'monthly') return s + sup.monthly_cost_cents;
    if (sup.billing_cycle === 'yearly') return s + Math.round(sup.monthly_cost_cents / 12);
    return s;
  }, 0);

  const yearlyTotal = active.reduce((s, sup) => {
    if (sup.billing_cycle === 'yearly') return s + sup.monthly_cost_cents;
    if (sup.billing_cycle === 'monthly') return s + sup.monthly_cost_cents * 12;
    return s;
  }, 0);

  const upcomingCancellations = active.filter(s => {
    if (!s.contract_end_date) return false;
    const days = daysUntil(s.contract_end_date);
    return days !== null && days <= 30 && days >= -30;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-medium text-ink-900">
            Tool-Abos & Lieferanten
          </h1>
          <p className="text-sm text-ink-500 mt-0.5">
            {active.length} aktiv · {formatMoney(monthlyTotal)}/Monat · {formatMoney(yearlyTotal)}/Jahr
          </p>
        </div>

        <button
          onClick={() => {
            setEditingSupplier(null);
            setShowAdd(true);
          }}
          className="btn-primary"
        >
          <Plus size={16} /> Neuer Eintrag
        </button>
      </div>

      {upcomingCancellations.length > 0 && (
        <div className="card p-4 bg-warning-50 border border-warning-500/20">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle size={16} className="text-warning-600" />
            <p className="text-sm font-medium text-warning-700">
              {upcomingCancellations.length} Kündigungsfrist(en) bald
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            {upcomingCancellations.map(s => (
              <span key={s.id} className="chip bg-white text-warning-700 text-2xs">
                <Calendar size={10} /> {s.name} · {formatDate(s.contract_end_date)}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="card p-5">
        <SectionHeader title="Alle Einträge" />

        {list.length === 0 ? (
          <EmptyState
            icon={<Building2 size={24} />}
            title="Keine Lieferanten"
            hint="Erfasse Hosting, Software-Abos und andere wiederkehrende Kosten."
          />
        ) : (
          <div className="divide-y divide-line">
            {list.map(s => {
              const days = s.contract_end_date ? daysUntil(s.contract_end_date) : null;

              return (
                <div key={s.id} className="flex items-center gap-3 py-3 group">
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                      s.active
                        ? 'bg-accent-50 text-accent-600'
                        : 'bg-surfaceMuted text-ink-400'
                    }`}
                  >
                    <Building2 size={16} />
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-ink-900 truncate">{s.name}</p>

                    <p className="text-2xs text-ink-500">
                      {s.category ? CATEGORY_LABELS[s.category] || s.category : 'Sonstige'}
                      {s.billing_cycle === 'monthly'
                        ? ` · ${formatMoney(s.monthly_cost_cents)}/Monat`
                        : s.billing_cycle === 'yearly'
                        ? ` · ${formatMoney(s.monthly_cost_cents)}/Jahr`
                        : ` · ${formatMoney(s.monthly_cost_cents)}`}
                      {s.notice_period_days > 0 && ` · Künd. ${s.notice_period_days}T`}
                    </p>
                  </div>

                  {s.contract_end_date && days !== null && days <= 30 && days >= -30 && (
                    <Badge tone="warning">
                      Künd. bis {formatDate(s.contract_end_date)}
                    </Badge>
                  )}

                  {s.url && (
                    <a
                      href={s.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 text-ink-400 hover:text-accent-600"
                    >
                      <ExternalLink size={14} />
                    </a>
                  )}

                  <button
                    onClick={() => toggleActive(s)}
                    className={`chip text-2xs ${
                      s.active
                        ? 'bg-success-50 text-success-700'
                        : 'bg-surfaceMuted text-ink-500'
                    }`}
                  >
                    {s.active ? 'Aktiv' : 'Inaktiv'}
                  </button>

                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => {
                        setEditingSupplier(s);
                        setShowAdd(true);
                      }}
                      className="p-1 text-ink-400 hover:text-accent-600"
                      title="Bearbeiten"
                    >
                      <Pencil size={14} />
                    </button>

                    <button
                      onClick={() => remove(s.id)}
                      className="p-1 text-ink-400 hover:text-danger-600"
                      title="Löschen"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <AddSupplierModal
        open={showAdd}
        supplier={editingSupplier}
        onAdded={() => {
          load();
          setEditingSupplier(null);
        }}
        onClose={() => {
          setShowAdd(false);
          setEditingSupplier(null);
        }}
      />
    </div>
  );
}

/* ---------------------------------------------------------------------- */

function AddSupplierModal({
  open,
  onAdded,
  onClose,
  supplier,
}: {
  open: boolean;
  onAdded: () => void;
  onClose: () => void;
  supplier: Supplier | null;
}) {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('software');
  const [cost, setCost] = useState('');
  const [cycle, setCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [noticeDays, setNoticeDays] = useState('30');
  const [endDate, setEndDate] = useState('');
  const [url, setUrl] = useState('');
  const [notes, setNotes] = useState('');
  const [firstDate, setFirstDate] = useState(() => {
    const d = new Date();
    d.setMonth(d.getMonth() + 1, 1);
    return d.toISOString().slice(0, 10);
  });

  const isEditing = !!supplier;

  useEffect(() => {
    if (supplier) {
      setName(supplier.name);
      setCategory(supplier.category);
      setCost((supplier.monthly_cost_cents / 100).toString());
      setCycle(supplier.billing_cycle === 'yearly' ? 'yearly' : 'monthly');
      setNoticeDays(String(supplier.notice_period_days || 0));
      setEndDate(supplier.contract_end_date || '');
      setUrl(supplier.url || '');
      setNotes(supplier.notes || '');
    } else {
      setName('');
      setCategory('software');
      setCost('');
      setCycle('monthly');
      setNoticeDays('30');
      setEndDate('');
      setUrl('');
      setNotes('');
      const d = new Date();
      d.setMonth(d.getMonth() + 1, 1);
      setFirstDate(d.toISOString().slice(0, 10));
    }
  }, [supplier, open]);

  async function submit() {
    if (!name.trim()) return;

    const costCents = cost ? Math.round(parseFloat(cost.replace(',', '.')) * 100) : 0;

    const supplierData = {
      name: name.trim(),
      category,
      monthly_cost_cents: costCents,
      billing_cycle: cycle,
      notice_period_days: noticeDays ? parseInt(noticeDays) : 0,
      contract_end_date: endDate || null,
      url: url.trim() || null,
      notes: notes.trim() || null,
    };

    if (supplier) {
      await suppliers.update(supplier.id, supplierData);
    } else {
      const id = await uuid();

      // Tool & Abo = immer automatisch wiederkehrend.
      await suppliers.insertWithRecurring(
        { id, ...supplierData, active: 1, created_at: new Date().toISOString() },
        true,
        firstDate
      );
    }

    onAdded();
    onClose();
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={supplier ? 'Lieferant bearbeiten' : 'Neuer Lieferant / Abo'}
      size="md"
      footer={
        <>
          <button onClick={onClose} className="btn-ghost">
            Abbrechen
          </button>
          <button
            onClick={submit}
            className="btn-primary"
            disabled={!name.trim()}
          >
            Speichern
          </button>
        </>
      }
    >
      <div className="space-y-3">
        <Field label="Name">
          <input
            className="input"
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoFocus
          />
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Kategorie">
            <select
              className="input"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="hosting">Hosting</option>
              <option value="software">Software</option>
              <option value="hardware">Hardware</option>
              <option value="service">Service</option>
            </select>
          </Field>

          <Field label="Abrechnung">
            <select
              className="input"
              value={cycle}
              onChange={(e) =>
                setCycle(e.target.value as 'monthly' | 'yearly')
              }
            >
              <option value="monthly">Monatlich</option>
              <option value="yearly">Jährlich</option>
            </select>
          </Field>
        </div>

        <Field label="Kosten (€)">
          <input
            className="input"
            value={cost}
            onChange={(e) => setCost(e.target.value)}
            inputMode="decimal"
          />
        </Field>

        <Field label="Kündigungsfrist (Tage)">
          <input
            className="input"
            value={noticeDays}
            onChange={(e) => setNoticeDays(e.target.value)}
          />
        </Field>

        <Field label="Vertragsende">
          <input
            type="date"
            className="input"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
          />
        </Field>

        <Field label="URL">
          <input
            className="input"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
          />
        </Field>

        <Field label="Notizen">
          <textarea
            className="input"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={2}
          />
        </Field>

        {!isEditing && (
          <div className="p-3 rounded-lg bg-surfaceAlt/50 space-y-2">
            <p className="text-2xs text-ink-500 flex items-center gap-1.5">
              <RefreshCw size={12} className="text-accent-600" />
              Wird automatisch als wiederkehrende Buchung in den Finanzen angelegt.
            </p>
            <Field label="Erste Fälligkeit">
              <input
                type="date"
                className="input"
                value={firstDate}
                onChange={(e) => setFirstDate(e.target.value)}
              />
            </Field>
          </div>
        )}
      </div>
    </Modal>
  );
}