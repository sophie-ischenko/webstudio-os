import { useEffect, useState, useCallback } from 'react';
import {
  Play,
  Square,
  Plus,
  Trash2,
  Clock,
  ChevronLeft,
  ChevronRight,
  BarChart3,
  Zap,
  CheckCircle,
  Calendar
} from 'lucide-react';
import { timeEntries, projects, phases, settings, uuid } from '../lib/db';
import type { TimeEntry, Project, ProjectPhase, EntityType } from '../types';
import { formatDuration, formatDate } from '../lib/format';
import { useRunningTimer, startTimer, stopAndSave, formatElapsed } from '../lib/timer';
import { Badge, EmptyState, Field, Modal } from '../components/ui';

function toLocalDate(isoDate: string) {
  const [y, m, d] = isoDate.split('-').map(Number);
  return new Date(y, m - 1, d);
}

function localISODate(date = new Date()) {
  const d = new Date(date);
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
}

function startOfWeekLocal(date: Date) {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  const day = d.getDay();
  const diff = (day === 0 ? -6 : 1) - day;
  d.setDate(d.getDate() + diff);
  return d;
}

// Ermittelt die echten Arbeitstage (Mo-Fr) eines Monats
function getWorkdaysInMonth(date: Date) {
  const start = new Date(date.getFullYear(), date.getMonth(), 1);
  const end = new Date(date.getFullYear(), date.getMonth() + 1, 0);
  let workdays = 0;

  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    const day = d.getDay();
    if (day !== 0 && day !== 6) { // 0 = Sonntag, 6 = Samstag
      workdays++;
    }
  }
  return workdays;
}

function AddTimeModal({
  open,
  onClose,
  projects,
  activePhases,
  onAdd
}: {
  open: boolean;
  onClose: () => void;
  projects: Project[];
  activePhases: ProjectPhase[];
  onAdd: (date: string, minutes: number, note: string, entityType: EntityType, entityId: string | null) => void;
}) {
  const [date, setDate] = useState(localISODate());
  const [hours, setHours] = useState('1');
  const [note, setNote] = useState('');
  const [entityType, setEntityType] = useState<EntityType>('project');
  const [entityId, setEntityId] = useState<string>('');
  const [phaseId, setPhaseId] = useState<string>('');

  useEffect(() => {
    if (open) setDate(localISODate());
  }, [open]);

  useEffect(() => {
    setPhaseId('');
  }, [entityId, entityType]);

  const phasesForProject = entityType === 'project' && entityId
    ? activePhases.filter(p => p.project_id === entityId)
    : [];

  function submit() {
    const minutes = Math.round(parseFloat(hours || '0') * 60);
    if (minutes <= 0) return;

    let finalType: EntityType = entityType;
    let finalId: string | null = entityType === 'project' ? entityId || null : null;

    if (entityType === 'project' && phaseId) {
      finalType = 'project_phase' as EntityType;
      finalId = phaseId;
    }

    onAdd(date, minutes, note, finalType, finalId);
    setNote('');
    setHours('1');
    setEntityId('');
    setPhaseId('');
    setEntityType('project');
    onClose();
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Zeit manuell erfassen"
      size="md"
      footer={
        <>
          <button onClick={onClose} className="btn-ghost">Abbrechen</button>
          <button onClick={submit} className="btn-primary">Speichern</button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Datum">
            <input type="date" className="input" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          <Field label="Stunden">
            <input type="number" step="0.25" min="0" className="input" value={hours} onChange={(e) => setHours(e.target.value)} />
          </Field>
        </div>

        <Field label="Bezug">
          <select className="input" value={entityType} onChange={(e) => setEntityType(e.target.value as EntityType)}>
            <option value="project">Projekt</option>
            <option value="social_post">Social Post</option>
            <option value="other">Sonstiges</option>
          </select>
        </Field>

        {entityType === 'project' && (
          <Field label="Projekt">
            <select className="input" value={entityId} onChange={(e) => setEntityId(e.target.value)}>
              <option value="">— Kein Projekt —</option>
              {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </Field>
        )}

        {entityType === 'project' && entityId && phasesForProject.length > 0 && (
          <Field label="Phase (optional)">
            <select className="input" value={phaseId} onChange={(e) => setPhaseId(e.target.value)}>
              <option value="">— Keiner bestimmten Phase zuordnen —</option>
              {phasesForProject.map(p => (
                <option key={p.id} value={p.id}>{p.name_override || 'Phase'}</option>
              ))}
            </select>
          </Field>
        )}

        <Field label="Notiz">
          <input
            className="input"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Was wurde gemacht?"
          />
        </Field>
      </div>
    </Modal>
  );
}

export function TimeView() {
  const [list, setList] = useState<TimeEntry[]>([]);
  const [projectList, setProjectList] = useState<Project[]>([]);
  const [activePhases, setActivePhases] = useState<ProjectPhase[]>([]);
  const [weekOffset, setWeekOffset] = useState(0);
  const [showAdd, setShowAdd] = useState(false);
  const [tab, setTab] = useState<'week' | 'capacity'>('week');
  const [weeklyCapacity, setWeeklyCapacity] = useState(40);
  const running = useRunningTimer();

  const load = useCallback(async () => {
    const [times, projs] = await Promise.all([timeEntries.list(), projects.list()]);
    setList(Array.isArray(times) ? times : []);
    setProjectList(Array.isArray(projs) ? projs : []);

    const phasesForCapacity: ProjectPhase[] = [];
    const activeProjects = Array.isArray(projs) ? projs.filter(p => p.status === 'active') : [];

    for (const p of activeProjects) {
      const ps = await phases.listByProject(p.id);
      phasesForCapacity.push(...ps.filter(ph => ph.status === 'open' || ph.status === 'in_progress'));
    }

    setActivePhases(phasesForCapacity);

    const capRow = await settings.get('weekly_capacity_hours');
    setWeeklyCapacity(capRow ? parseFloat(capRow.value) || 40 : 40);
  }, []);

  useEffect(() => {
    load();
  }, [load, running]);

  const baseDate = new Date();
  baseDate.setDate(baseDate.getDate() + weekOffset * 7);
  const weekStart = startOfWeekLocal(baseDate);
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 6);
  weekEnd.setHours(23, 59, 59, 999);

  const monthStart = new Date(baseDate.getFullYear(), baseDate.getMonth(), 1);
  monthStart.setHours(0, 0, 0, 0);
  const monthEnd = new Date(baseDate.getFullYear(), baseDate.getMonth() + 1, 0);
  monthEnd.setHours(23, 59, 59, 999);

  const weekEntries = list.filter(t => {
    const d = toLocalDate(t.entry_date);
    return d >= weekStart && d <= weekEnd;
  });

  const byDay: Record<string, TimeEntry[]> = {};
  weekEntries.forEach(t => {
    (byDay[t.entry_date] = byDay[t.entry_date] || []).push(t);
  });

  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(weekStart);
    d.setDate(d.getDate() + i);
    const iso = d.toISOString().slice(0, 10);
    return iso;
  }).filter(date => (byDay[date] || []).length > 0);

  const weekTotal = weekEntries.reduce((s, t) => s + t.minutes, 0);

  const dayTotals = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(weekStart);
    d.setDate(d.getDate() + i);
    const iso = d.toISOString().slice(0, 10);
    return {
      date: iso,
      minutes: (byDay[iso] || []).reduce((s, t) => s + t.minutes, 0)
    };
  });

  const maxDay = Math.max(...dayTotals.map(d => d.minutes), 60);

  const typeStats = Object.entries(
    weekEntries.reduce((map: Record<string, number>, t) => {
      map[t.entity_type] = (map[t.entity_type] || 0) + t.minutes;
      return map;
    }, {})
  ).map(([key, minutes]) => ({ key, minutes }));

  function entityLabel(t: TimeEntry): string {
    if (t.entity_type === 'project') {
      const p = projectList.find(p => p.id === t.entity_id);
      return p?.name || 'Unbekanntes Projekt';
    }
    if (t.entity_type === 'project_phase') {
      const phase = activePhases.find(ph => ph.id === t.entity_id);
      if (!phase) return 'Projekt-Phase';
      const project = projectList.find(p => p.id === phase.project_id);
      const phaseName = phase.name_override || 'Phase';
      return project ? `${project.name} · ${phaseName}` : phaseName;
    }
    if (t.entity_type === 'social_post') return 'Social Post';
    return 'Sonstiges';
  }

  async function addManual(date: string, minutes: number, note: string, entityType: EntityType, entityId: string | null) {
    const id = await uuid();
    await timeEntries.insert({
      id,
      entity_type: entityType,
      entity_id: entityId,
      minutes,
      entry_date: date,
      note: note || null,
      created_at: new Date().toISOString()
    });
    await load();
  }

  async function removeEntry(id: string) {
    await timeEntries.remove(id);
    await load();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-medium text-ink-900">Zeiterfassung</h1>
          <p className="text-sm text-ink-500">Live-Timer, Wochenübersicht und Kapazitätsplanung</p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex rounded-lg bg-surfaceMuted p-0.5">
            <button
              onClick={() => setTab('week')}
              className={`px-3 py-1.5 text-sm font-medium rounded-md transition-all flex items-center gap-1.5 ${tab === 'week' ? 'bg-surface text-ink-900 shadow-sm' : 'text-ink-500 hover:text-ink-700'}`}
            >
              <Calendar size={14} /> Woche
            </button>
            <button
              onClick={() => setTab('capacity')}
              className={`px-3 py-1.5 text-sm font-medium rounded-md transition-all flex items-center gap-1.5 ${tab === 'capacity' ? 'bg-surface text-ink-900 shadow-sm' : 'text-ink-500 hover:text-ink-700'}`}
            >
              <BarChart3 size={14} /> Kapazität
            </button>
          </div>

          <button onClick={() => setShowAdd(true)} className="btn-outline">
            <Plus size={16} /> Manuell
          </button>
        </div>
      </div>

      <div className="card p-5">
        {running ? (
          <div className="flex items-center justify-between gap-5">
            <div className="flex items-center gap-4">
              <span className="w-3 h-3 rounded-full bg-accent-500 animate-pulse-soft" />
              <div>
                <p className="text-sm font-medium text-ink-900">
                  {running.entityType === 'project' ? 'Projekt' : running.entityType === 'social_post' ? 'Social Post' : running.entityType}
                </p>
                {running.note && <p className="text-2xs text-ink-500">{running.note}</p>}
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="font-mono text-3xl font-medium text-accent-700 tabular-nums">{formatElapsed()}</span>
              <button onClick={() => stopAndSave().then(() => load())} className="btn-primary">
                <Square size={16} /> Stoppen & speichern
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between gap-5">
            <div className="flex items-center gap-3 text-ink-500">
              <Clock size={20} />
              <p className="text-sm">Kein Timer aktiv. Starte einen Timer aus einem Projekt oder manuell.</p>
            </div>
            <button onClick={() => startTimer('other', null, 'Allgemein')} className="btn-outline">
              <Play size={16} /> Timer starten
            </button>
          </div>
        )}
      </div>

      {tab === 'week' ? (
        <WeekTab
          dayTotals={dayTotals}
          maxDay={maxDay}
          weekStart={weekStart}
          weekEnd={weekEnd}
          weekTotal={weekTotal}
          weekOffset={weekOffset}
          setWeekOffset={setWeekOffset}
          typeStats={typeStats}
          days={days}
          byDay={byDay}
          entityLabel={entityLabel}
          removeEntry={removeEntry}
        />
      ) : (
        <CapacityTab
          projectList={projectList}
          activePhases={activePhases}
          timeEntries={list}
          weeklyCapacity={weeklyCapacity}
          monthStart={monthStart}
          monthEnd={monthEnd}
          onRefresh={load}
        />
      )}

      <AddTimeModal open={showAdd} onClose={() => setShowAdd(false)} projects={projectList} activePhases={activePhases} onAdd={addManual} />
    </div>
  );
}

function WeekTab({
  dayTotals,
  maxDay,
  weekStart,
  weekEnd,
  weekTotal,
  weekOffset,
  setWeekOffset,
  typeStats,
  days,
  byDay,
  entityLabel,
  removeEntry
}: {
  dayTotals: { date: string; minutes: number }[];
  maxDay: number;
  weekStart: Date;
  weekEnd: Date;
  weekTotal: number;
  weekOffset: number;
  setWeekOffset: (f: (w: number) => number) => void;
  typeStats: { key: string; minutes: number }[];
  days: string[];
  byDay: Record<string, TimeEntry[]>;
  entityLabel: (t: TimeEntry) => string;
  removeEntry: (id: string) => void;
}) {
  return (
    <div className="card p-5 space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <button onClick={() => setWeekOffset(w => w - 1)} className="p-1.5 rounded-lg hover:bg-surfaceAlt"><ChevronLeft size={18} /></button>
          <button onClick={() => setWeekOffset(() => 0)} className="btn-ghost text-sm">Heute</button>
          <button onClick={() => setWeekOffset(w => w + 1)} className="p-1.5 rounded-lg hover:bg-surfaceAlt"><ChevronRight size={18} /></button>
        </div>
        <p className="text-sm font-medium text-ink-900">
          {formatDate(weekStart.toISOString())} – {formatDate(weekEnd.toISOString())}
        </p>
        <div className="text-right">
          <p className="text-2xs text-ink-500 uppercase tracking-wider">Woche gesamt</p>
          <p className="stat-value text-accent-700">{formatDuration(weekTotal)}</p>
        </div>
      </div>

      {/* KORREKTUR: items-stretch am übergeordneten Container, damit die Spalten die volle Höhe ausfüllen */}
      <div className="flex items-stretch justify-between gap-3 h-32">
        {dayTotals.map(d => {
          const heightPct = (d.minutes / maxDay) * 100;
          const isToday = d.date === localISODate();
          return (
            <div key={d.date} className="flex-1 flex flex-col items-center justify-between">
              <span className={`text-[11px] tabular-nums font-medium ${isToday ? 'text-accent-700' : 'text-ink-600'}`}>
                {d.minutes > 0 ? `${Math.round((d.minutes / 60) * 10) / 10}h` : '0h'}
              </span>
              
              {/* KORREKTUR: Feste Höhe h-20 und ein dezenter grauer Hintergrund-Pfad */}
              <div className="w-full h-20 bg-surfaceMuted/20 rounded-md flex items-end overflow-hidden">
                <div
                  className={`w-full rounded-t-md transition-all duration-500 ${isToday ? 'bg-accent-600' : 'bg-accent-300'}`}
                  style={{ height: `${Math.max(heightPct, 4)}%` }}
                />
              </div>
              
              <span className={`text-[11px] font-medium ${isToday ? 'text-ink-900' : 'text-ink-500'}`}>
                {new Date(d.date).toLocaleDateString('de-DE', { weekday: 'short' }).slice(0, 2)}
              </span>
            </div>
          );
        })}
      </div>

      {typeStats.length > 0 && (
        <div className="space-y-3">
          <p className="text-sm font-medium text-ink-700">Zeit nach Kategorie</p>
          {typeStats.map(t => {
            const pct = weekTotal ? (t.minutes / weekTotal) * 100 : 0;
            return (
              <div key={t.key} className="space-y-1.5">
                <div className="flex justify-between text-sm">
                  <span className="capitalize text-ink-700">{t.key}</span>
                  <span className="text-ink-500">{formatDuration(t.minutes)}</span>
                </div>
                <div className="h-2 bg-surfaceAlt rounded-full overflow-hidden">
                  <div className="h-full bg-accent-500 rounded-full" style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      )}

      {days.length === 0 ? (
        <EmptyState icon={<Clock size={24} />} title="Keine Einträge diese Woche" hint="Starte einen Timer oder füge manuell Zeit hinzu." />
      ) : (
        <div className="space-y-5">
          {days.map(date => (
            <div key={date} className="space-y-2">
              <p className="text-2xs font-semibold uppercase tracking-wider text-ink-500">
                {formatDate(date)} · {formatDuration(byDay[date].reduce((s, t) => s + t.minutes, 0))}
              </p>
              {byDay[date].map(t => (
                <div key={t.id} className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-surfaceAlt/40 group">
                  <span className="text-sm font-medium text-ink-900 flex-1">{entityLabel(t)}</span>
                  {t.note && <span className="text-2xs text-ink-500 truncate max-w-[200px]">{t.note}</span>}
                  <Badge tone="neutral">{formatDuration(t.minutes)}</Badge>
                  <button onClick={() => removeEntry(t.id)} className="p-1 text-ink-400 hover:text-danger-600 opacity-0 group-hover:opacity-100">
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}


function CapacityTab({
  projectList,
  activePhases,
  timeEntries,
  weeklyCapacity,
  monthStart,
  monthEnd,
  onRefresh
}: {
  projectList: Project[];
  activePhases: ProjectPhase[];
  timeEntries: TimeEntry[];
  weeklyCapacity: number;
  monthStart: Date;
  monthEnd: Date;
  onRefresh: () => void;
}) {
  const [editingPhase, setEditingPhase] = useState<string | null>(null);
  const [editHours, setEditHours] = useState('');

  // 1. Helfer: Arbeitstage im Monat (Mo-Fr) zählen
  const getWorkdaysInMonth = (date: Date) => {
    const start = new Date(date.getFullYear(), date.getMonth(), 1);
    const end = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    let workdays = 0;
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const day = d.getDay();
      if (day !== 0 && day !== 6) workdays++;
    }
    return workdays;
  };

  // 2. Berechnungen
  const monthName = monthStart.toLocaleDateString('de-DE', { month: 'long', year: 'numeric' });
  const dailyCapacity = weeklyCapacity / 5;
  const monthlyCapacityTotal = dailyCapacity * getWorkdaysInMonth(monthStart);

  const monthEntries = timeEntries.filter(t => {
    const d = toLocalDate(t.entry_date);
    return d >= monthStart && d <= monthEnd;
  });

  const trackedHours = monthEntries.reduce((s, t) => s + t.minutes, 0) / 60;

  const phaseLoggedHours = (phaseId: string) =>
    timeEntries
      .filter(t => (t.entity_type === 'project_phase' || t.entity_type === 'phase') && t.entity_id === phaseId)
      .reduce((s, t) => s + t.minutes, 0) / 60;

  const plannedRemaining = activePhases.reduce((sum, phase) => {
    const logged = phaseLoggedHours(phase.id);
    const estimated = phase.estimated_hours || 0;
    return sum + Math.max(estimated - logged, 0);
  }, 0);

  const freeHours = monthlyCapacityTotal - trackedHours - plannedRemaining;
  const trackedPct = Math.min((trackedHours / monthlyCapacityTotal) * 100, 100);
  const plannedPct = Math.min((plannedRemaining / monthlyCapacityTotal) * 100, 100);

  const saveEstimate = async (phaseId: string) => {
    const hours = parseFloat(editHours) || 0;
    await phases.update(phaseId, { estimated_hours: hours });
    setEditingPhase(null);
    onRefresh();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      
      {/* Bento-Grid Statistiken */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card p-4 border-l-4 border-l-slate-300">
          <p className="text-2xs font-bold uppercase tracking-wider text-ink-500 mb-1">Monats-Limit</p>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-semibold text-ink-900">{monthlyCapacityTotal}</span>
            <span className="text-xs text-ink-500">h</span>
          </div>
          <p className="text-[10px] text-ink-400 mt-1">{getWorkdaysInMonth(monthStart)} Arbeitstage</p>
        </div>

        <div className="card p-4 border-l-4 border-l-accent-500">
          <p className="text-2xs font-bold uppercase tracking-wider text-accent-600 mb-1 flex items-center gap-1">
            <Zap size={10} /> Erfasst
          </p>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-semibold text-ink-900">{trackedHours.toFixed(1)}</span>
            <span className="text-xs text-ink-500">h</span>
          </div>
          <p className="text-[10px] text-ink-400 mt-1">{trackedPct.toFixed(0)}% Auslastung</p>
        </div>

        <div className="card p-4 border-l-4 border-l-accent-300">
          <p className="text-2xs font-bold uppercase tracking-wider text-accent-400 mb-1">Geplant (Rest)</p>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-semibold text-ink-900">{plannedRemaining.toFixed(1)}</span>
            <span className="text-xs text-ink-500">h</span>
          </div>
          <p className="text-[10px] text-ink-400 mt-1">Aus Schätzungen</p>
        </div>

        <div className="card p-4 border-l-4 border-l-success-500">
          <p className="text-2xs font-bold uppercase tracking-wider text-success-600 mb-1">Verfügbar</p>
          <div className="flex items-baseline gap-1">
            <span className={`text-2xl font-semibold ${freeHours < 0 ? 'text-danger-600' : 'text-success-600'}`}>
              {freeHours.toFixed(1)}
            </span>
            <span className="text-xs text-ink-500">h</span>
          </div>
          <p className="text-[10px] text-ink-400 mt-1">{freeHours < 0 ? 'Überbucht' : 'Freie Kapazität'}</p>
        </div>
      </div>

      {/* Visuelle Balken */}
      <div className="card p-5 space-y-5">
        <h3 className="text-sm font-semibold text-ink-900 flex items-center gap-2">
          <BarChart3 size={16} className="text-accent-500" /> Kapazitäts-Visualisierung
        </h3>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-ink-600 font-medium">Bereits erfasst</span>
              <span className="text-ink-900 font-bold">{trackedHours.toFixed(1)} h</span>
            </div>
            <div className="h-3 bg-surfaceMuted rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all duration-700 ${trackedHours > monthlyCapacityTotal ? 'bg-danger-500' : 'bg-accent-500'}`}
                style={{ width: `${trackedPct}%` }}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-ink-600 font-medium">Geplant (Soll-Rest)</span>
              <span className="text-ink-900 font-bold">{plannedRemaining.toFixed(1)} h</span>
            </div>
            <div className="h-3 bg-surfaceMuted rounded-full overflow-hidden">
              <div 
                className="bg-accent-300 h-full transition-all duration-700"
                style={{ width: `${plannedPct}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Phasen Planung */}
      <div className="card p-5">
        <h3 className="text-sm font-semibold text-ink-900 mb-4">Projektphasen (Schätzungen bearbeiten)</h3>
        <div className="divide-y divide-line">
          {activePhases.map(phase => {
            const isEditing = editingPhase === phase.id;
            const logged = phaseLoggedHours(phase.id);
            const remaining = Math.max((phase.estimated_hours || 0) - logged, 0);

            return (
              <div key={phase.id} className="flex justify-between items-center py-3 group">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-ink-900 truncate">
                    {projectList.find(p => p.id === phase.project_id)?.name || 'Unbekannt'}
                  </p>
                  <p className="text-2xs text-ink-500">{phase.name_override || 'Phase'}</p>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-xs font-bold text-ink-900">{remaining.toFixed(1)} h offen</p>
                    <p className="text-[10px] text-ink-400">{logged.toFixed(1)}h erfasst</p>
                  </div>
                  
                  {isEditing ? (
                    <div className="flex items-center gap-1">
                      <input
                        className="input w-16 h-8 text-sm"
                        autoFocus
                        value={editHours}
                        onChange={e => setEditHours(e.target.value)}
                        onKeyDown={e => {
                          if (e.key === 'Enter') saveEstimate(phase.id);
                          if (e.key === 'Escape') setEditingPhase(null);
                        }}
                      />
                      <button onClick={() => saveEstimate(phase.id)} className="p-1.5 text-success-600"><CheckCircle size={16} /></button>
                    </div>
                  ) : (
                    <button 
                      onClick={() => { setEditingPhase(phase.id); setEditHours(String(phase.estimated_hours || '')); }}
                      className="p-2 text-ink-400 hover:text-accent-600 opacity-0 group-hover:opacity-100 transition-all"
                    >
                      ✎
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Analyse Banner */}
      <div className={`p-4 rounded-xl border flex items-start gap-3 ${
        freeHours < 0 ? "bg-danger-50 border-danger-100 text-danger-700" : "bg-success-50 border-success-100 text-success-700"
      }`}>
        {freeHours < 0 ? <ShieldAlert size={18} /> : <CheckCircle size={18} />}
        <div className="text-xs leading-relaxed">
          <p className="font-bold">Analyse für {monthName}</p>
          <p className="opacity-90">
            {freeHours < 0 
              ? `Achtung: Du bist um ${Math.abs(freeHours).toFixed(1)} Stunden überbucht.` 
              : `Du hast noch ${freeHours.toFixed(1)} Stunden Kapazität für diesen Monat.`}
          </p>
        </div>
      </div>
    </div>
  );
}