import { useState, useEffect } from 'react';
import { Plus, Search, Trash2 } from 'lucide-react';

import { projects, clients, templates, uuid } from '../lib/db';
import type { Project, Client, PhaseTemplate } from '../types';
import { Badge, Field, SectionHeader, EmptyState } from '../components/ui';
import { ProjectDetailView } from './ProjectDetailView';

export function ProjectsView() {
  const [projectList, setProjectList] = useState<Project[]>([]);
  const [clientList, setClientList] = useState<Client[]>([]);
  const [templateList, setTemplateList] = useState<PhaseTemplate[]>([]);
  const [showNewModal, setShowNewModal] = useState(false);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'paused' | 'completed' | 'cancelled'>('active');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProjects();
    loadClients();
    loadTemplates();
  }, []);

  async function loadProjects() {
    setLoading(true);
    try {
      const p = await projects.list();
      setProjectList(p);
    } finally {
      setLoading(false);
    }
  }

  async function loadClients() {
    const c = await clients.list();
    setClientList(c);
  }

  async function loadTemplates() {
    const t = await templates.list();
    setTemplateList(t);
  }

  async function handleCreateProject(data: {
    name: string;
    client_name: string;
    client_id?: string;
    client_company?: string;
    client_email?: string;
    client_phone?: string;
    client_address?: string;
    template_id?: string;
    start_date: string;
    target_end_date?: string;
  }) {
    const projectId = await uuid();
    await projects.insert({
      id: projectId,
      name: data.name,
      client_name: data.client_name,
      client_id: data.client_id,
      client_company: data.client_company,
      client_email: data.client_email,
      client_phone: data.client_phone,
      client_address: data.client_address,
      template_id: data.template_id,
      status: 'active',
      start_date: data.start_date,
      target_end_date: data.target_end_date,
      notes: null,
      created_at: new Date().toISOString(),
    });

    // Wenn Template gesetzt, Phasen hinzufügen
    if (data.template_id) {
      const template = await templates.get(data.template_id);
      if (template) {
        const templateItems = await templates.items(data.template_id);
        for (let i = 0; i < templateItems.length; i++) {
          const item = templateItems[i];
          const phaseId = await uuid();

          // Phase erstellen
          const { phases } = await import('../lib/db');
          await phases.insert({
            id: phaseId,
            project_id: projectId,
            phase_template_item_id: item.id,
            name_override: null,
            status: 'pending',
            deadline: null,
            position_override: i,
            created_at: new Date().toISOString(),
          });

          // Checklisten items hinzufügen
          const checklistItems = await templates.checklistItems(item.id);
          const { checklist } = await import('../lib/db');
          for (let j = 0; j < checklistItems.length; j++) {
            const checkItem = checklistItems[j];
            await checklist.insert({
              id: await uuid(),
              project_phase_id: phaseId,
              checklist_template_item_id: checkItem.id,
              label_override: null,
              is_checked: 0,
              position_override: j,
              created_at: new Date().toISOString(),
            });
          }
        }
      }
    }

    setShowNewModal(false);
    await loadProjects();
  }

  async function deleteProject(id: string) {
    if (!confirm('Projekt wirklich löschen?')) return;
    await projects.remove(id);
    await loadProjects();
  }

  // Filter nach Status und Suchbegriff
  const filtered = projectList.filter(p => {
    const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.client_name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  // Wenn ein Projekt ausgewählt, zeige Detail-View
  if (selectedProjectId) {
    return (
      <ProjectDetailView
        projectId={selectedProjectId}
        onBack={() => setSelectedProjectId(null)}
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-medium text-ink-900">Projekte</h1>
          <p className="text-sm text-ink-500 mt-0.5">Verwalte deine Webdesign Projekte</p>
        </div>
        <button onClick={() => setShowNewModal(true)} className="btn-primary">
          <Plus size={14} /> Neues Projekt
        </button>
      </div>

      {/* Filter & Suche */}
      <div className="card p-4 space-y-3">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search size={14} className="absolute left-3 top-3 text-ink-400" />
            <input
              type="text"
              placeholder="Nach Projektname oder Kundin suchen…"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input pl-9 w-full"
            />
          </div>
        </div>

        {/* Status Filter */}
        <div className="flex gap-2 flex-wrap">
          {[
            { value: 'all' as const, label: 'Alle', icon: '📊' },
            { value: 'active' as const, label: 'Aktiv', icon: '🟢' },
            { value: 'paused' as const, label: 'Pausiert', icon: '⏸️' },
            { value: 'completed' as const, label: 'Abgeschlossen', icon: '✅' },
            { value: 'cancelled' as const, label: 'Abgebrochen', icon: '❌' },
          ].map(s => (
            <button
              key={s.value}
              onClick={() => setStatusFilter(s.value)}
              className={`chip text-sm ${statusFilter === s.value ? 'bg-accent-600 text-white' : 'bg-surface text-ink-700'}`}
            >
              {s.icon} {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Projekte Liste */}
      {loading ? (
        <div className="p-6 text-center text-ink-500">Lädt…</div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<Plus size={22} />}
          title={searchTerm ? 'Keine Ergebnisse' : 'Keine Projekte'}
          hint={searchTerm ? 'Versuche einen anderen Suchbegriff' : 'Erstelle dein erstes Projekt'}
        />
      ) : (
        <div className="grid gap-3">
          {filtered.map(p => (
            <div
              key={p.id}
              onClick={() => setSelectedProjectId(p.id)}
              className="card p-4 hover:shadow-md cursor-pointer transition-all group"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-medium text-ink-900">{p.name}</h3>
                    <StatusBadge status={p.status} />
                  </div>
                  <p className="text-sm text-ink-600">{p.client_name}</p>
                  {p.client_company && (
                    <p className="text-2xs text-ink-400 mt-1">{p.client_company}</p>
                  )}
                </div>
                <div className="text-right">
                  <p className="text-2xs text-ink-400">
                    {new Date(p.start_date).toLocaleDateString('de-DE')}
                  </p>
                  {p.target_end_date && (
                    <p className="text-2xs text-ink-400">
                      bis {new Date(p.target_end_date).toLocaleDateString('de-DE')}
                    </p>
                  )}
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteProject(p.id);
                  }}
                  className="p-2 text-ink-400 hover:text-danger-600 opacity-0 group-hover:opacity-100 transition-opacity ml-2"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* New Project Modal */}
      <NewProjectModal
        isOpen={showNewModal}
        onClose={() => setShowNewModal(false)}
        onSubmit={handleCreateProject}
        clientList={clientList}
        templates={templateList}
      />
    </div>
  );
}

// Status Badge
function StatusBadge({ status }: { status: string }) {
  const statusMap: Record<string, { icon: string; label: string; tone: 'success' | 'warning' | 'info' | 'danger' }> = {
    active: { icon: '🟢', label: 'Aktiv', tone: 'success' },
    paused: { icon: '⏸️', label: 'Pausiert', tone: 'warning' },
    completed: { icon: '✅', label: 'Abgeschlossen', tone: 'info' },
    cancelled: { icon: '❌', label: 'Abgebrochen', tone: 'danger' },
  };
  const s = statusMap[status] || statusMap.active;
  return <Badge tone={s.tone}>{s.icon} {s.label}</Badge>;
}

// New Project Modal
function NewProjectModal({ isOpen, onClose, onSubmit, clientList, templates }: {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (p: any) => void;
  clientList: Client[];
  templates: any[];
}) {
  const [name, setName] = useState('');
  const [selectedClientId, setSelectedClientId] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [targetDate, setTargetDate] = useState('');

  const selectedClient = selectedClientId
    ? clientList.find(c => c.id === selectedClientId)
    : null;

  function submit() {
    if (!name.trim()) {
      alert('Projektname ist erforderlich');
      return;
    }

    onSubmit({
      name: name.trim(),
      client_name: selectedClient?.name || 'Unbekannt',
      client_id: selectedClientId || undefined,
      client_company: selectedClient?.company,
      client_email: selectedClient?.email,
      client_phone: selectedClient?.phone,
      client_address: selectedClient?.address,
      template_id: selectedTemplate || undefined,
      start_date: startDate,
      target_end_date: targetDate || undefined,
    });

    setName('');
    setSelectedClientId('');
    setSelectedTemplate('');
    setStartDate(new Date().toISOString().split('T')[0]);
    setTargetDate('');
  }

  if (!isOpen) return null;

  return (
    <dialog open className="modal">
      <div className="modal-box max-w-md space-y-4">
        <h2 className="text-xl font-medium text-ink-900">Neues Projekt</h2>

        {/* Projektname */}
        <div>
          <label className="label">Projektname *</label>
          <input
            type="text"
            className="input"
            placeholder="z.B. Website Relaunch Müller GmbH"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && submit()}
          />
        </div>

        {/* Kundin */}
        <div>
          <label className="label">Kundin</label>
          <select
            className="input"
            value={selectedClientId}
            onChange={(e) => setSelectedClientId(e.target.value)}
          >
            <option value="">— Kundin wählen —</option>
            {clientList.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>

        {/* Kundinnen-Daten */}
        {selectedClient && (
          <div className="p-4 rounded-lg bg-accent-50 border border-accent-200 space-y-3">
            <div>
              <p className="text-2xs font-semibold uppercase text-accent-600">Kundin</p>
              <p className="text-sm font-medium text-ink-900 mt-1">{selectedClient.name}</p>
            </div>
            {selectedClient.company && (
              <div>
                <p className="text-2xs font-semibold uppercase text-accent-600">Firma</p>
                <p className="text-sm text-ink-700">{selectedClient.company}</p>
              </div>
            )}
            {selectedClient.email && (
              <div>
                <p className="text-2xs font-semibold uppercase text-accent-600">E-Mail</p>
                <p className="text-sm text-ink-700">{selectedClient.email}</p>
              </div>
            )}
            {selectedClient.phone && (
              <div>
                <p className="text-2xs font-semibold uppercase text-accent-600">Telefon</p>
                <p className="text-sm text-ink-700">{selectedClient.phone}</p>
              </div>
            )}
            {selectedClient.address && (
              <div>
                <p className="text-2xs font-semibold uppercase text-accent-600">Adresse</p>
                <p className="text-sm text-ink-700">{selectedClient.address}</p>
              </div>
            )}
          </div>
        )}

        {/* Template */}
        <div>
          <label className="label">Phasen-Vorlage (optional)</label>
          <select
            className="input"
            value={selectedTemplate}
            onChange={(e) => setSelectedTemplate(e.target.value)}
          >
            <option value="">— Keine Vorlage —</option>
            {templates.map(t => (
              <option key={t.id} value={t.id}>{t.name}</option>
            ))}
          </select>
        </div>

        {/* Startdatum */}
        <div>
          <label className="label">Startdatum *</label>
          <input
            type="date"
            className="input"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
          />
        </div>

        {/* Zieldatum */}
        <div>
          <label className="label">Zieldatum (optional)</label>
          <input
            type="date"
            className="input"
            value={targetDate}
            onChange={(e) => setTargetDate(e.target.value)}
          />
        </div>

        {/* Buttons */}
        <div className="flex gap-2 justify-end pt-2">
          <button onClick={onClose} className="btn-ghost">Abbrechen</button>
          <button onClick={submit} className="btn-primary">Erstellen</button>
        </div>
      </div>
      <div className="modal-backdrop" onClick={onClose} />
    </dialog>
  );
}