import { useEffect, useState, useRef } from 'react';
import { Search, FolderKanban, FileText, CheckSquare, Calendar, X } from 'lucide-react';
import { projects, invoices, todos, posts } from '../lib/db';
import type { Project, Invoice, Todo, SocialPost } from '../types';
import { formatMoney } from '../lib/format';

interface SearchResult {
  type: 'project' | 'invoice' | 'todo' | 'post';
  id: string;
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  view: string;
}

export function GlobalSearch({ onNavigate }: { onNavigate: (view: string) => void }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!query.trim() || query.trim().length < 2) { setResults([]); return; }
    const q = query.trim().toLowerCase();
    (async () => {
      const [projs, invs, tds, psts] = await Promise.all([
        projects.all(), invoices.all(), todos.all(), posts.all(),
      ]);
      const r: SearchResult[] = [];
      for (const p of (projs as Project[])) {
        if (p.name.toLowerCase().includes(q) || (p.client_name || '').toLowerCase().includes(q))
          r.push({ type: 'project', id: p.id, title: p.name, subtitle: p.client_name || 'Projekt', icon: <FolderKanban size={14} />, view: 'projects' });
      }
      for (const i of (invs as Invoice[])) {
        const num = i.invoice_number || '';
        if (num.toLowerCase().includes(q) || (i.client_name || '').toLowerCase().includes(q))
          r.push({ type: 'invoice', id: i.id, title: num || 'Rechnung', subtitle: `${i.client_name} · ${formatMoney(i.amount_cents)}`, icon: <FileText size={14} />, view: 'invoices' });
      }
      for (const t of (tds as Todo[])) {
        if (t.title.toLowerCase().includes(q))
          r.push({ type: 'todo', id: t.id, title: t.title, subtitle: t.status === 'done' ? 'Erledigt' : 'Offen', icon: <CheckSquare size={14} />, view: 'todos' });
      }
      for (const p of (psts as SocialPost[])) {
        if ((p.topic || '').toLowerCase().includes(q) || (p.caption || '').toLowerCase().includes(q))
          r.push({ type: 'post', id: p.id, title: p.topic || 'Post', subtitle: p.platform, icon: <Calendar size={14} />, view: 'social' });
      }
      setResults(r.slice(0, 12));
    })();
  }, [query]);

  useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  function select(r: SearchResult) {
    onNavigate(r.view);
    setOpen(false);
    setQuery('');
  }

  return (
    <div ref={ref} className="relative">
      <div className="relative">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
        <input
          className="w-full pl-9 pr-8 py-2 rounded-lg border border-line bg-surfaceAlt text-sm text-ink-900 placeholder:text-ink-400 focus:outline-none focus:border-accent-400 focus:ring-2 focus:ring-accent-100 transition-all"
          placeholder="Projekte, Rechnungen, To-dos, Posts suchen"
          value={query}
          onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
        />
        {query && (
          <button onClick={() => { setQuery(''); setResults([]); }} className="absolute right-2 top-1/2 -translate-y-1/2 text-ink-400 hover:text-ink-700">
            <X size={14} />
          </button>
        )}
      </div>
      {open && results.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-1 card shadow-pop z-50 max-h-80 overflow-y-auto animate-scale-in">
          {results.map(r => (
            <button
              key={`${r.type}-${r.id}`}
              onClick={() => select(r)}
              className="w-full flex items-center gap-3 px-3 py-2 hover:bg-surfaceAlt text-left transition-colors"
            >
              <span className="text-accent-600 shrink-0">{r.icon}</span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-ink-900 truncate">{r.title}</p>
                <p className="text-2xs text-ink-400 truncate">{r.subtitle}</p>
              </div>
              <span className="text-2xs text-ink-400 uppercase">{r.type}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
